import { useAuth } from '../auth/hooks/useAuth';
import { ChatPanel } from './components/ChatPanel';
import { QuickHints } from './components/QuickHints';
import { SuggestedServiceCard } from './components/SuggestedServiceCard';
import { VendorMap } from './components/VendorMap';
import { useAIConsultantChat } from './hooks/useAIConsultantChat';

export default function AIConsultant() {
  const { user } = useAuth();
  const {
    input,
    isTyping,
    messages,
    messagesEndRef,
    retrievedServices,
    setInput,
    submitMessage,
    suggestedService,
  } = useAIConsultantChat(user);

  return (
    <div className="w-full flex flex-col md:flex-row h-auto md:h-[calc(100vh-6rem)] md:max-h-[900px]">
      {/* Left: AI conversation */}
      <div className="w-full md:w-[30%] h-[600px] md:h-full min-h-0">
        <ChatPanel
          input={input}
          isTyping={isTyping}
          messages={messages}
          messagesEndRef={messagesEndRef}
          retrievedServices={retrievedServices}
          onInputChange={setInput}
          onSubmit={submitMessage}
        />
      </div>

      {/* Right: geographic context + supporting recommendations */}
      <aside className="w-full md:flex-1 h-auto md:h-full min-h-0 flex flex-col gap-4 overflow-y-auto">
        <VendorMap services={retrievedServices} />

        {suggestedService && <SuggestedServiceCard service={suggestedService} />}

        <QuickHints onSelectHint={setInput} />
      </aside>
    </div>
  );
}
