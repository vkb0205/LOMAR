import { useEffect } from 'react';
import {
  CircleMarker,
  MapContainer,
  Popup,
  TileLayer,
  useMap,
} from 'react-leaflet';
import { MapPin } from 'lucide-react';
import type { RetrievedService } from '../types';
import 'leaflet/dist/leaflet.css';

interface VendorMapProps {
  services: RetrievedService[];
}

const DEFAULT_CENTER: [number, number] = [10.7769, 106.7009];

function FitBounds({ points }: { points: Array<[number, number]> }) {
  const map = useMap();

  useEffect(() => {
    if (points.length === 0) return;

    if (points.length === 1) {
      map.setView(points[0], 14, { animate: false });
      return;
    }

    const latitudes = points.map(point => point[0]);
    const longitudes = points.map(point => point[1]);
    const southWest: [number, number] = [
      Math.min(...latitudes),
      Math.min(...longitudes),
    ];
    const northEast: [number, number] = [
      Math.max(...latitudes),
      Math.max(...longitudes),
    ];

    map.fitBounds([southWest, northEast], {
      padding: [40, 40],
      maxZoom: 14,
      animate: false,
    });
  }, [map, points]);

  return null;
}

function isLocated(
  service: RetrievedService,
): service is RetrievedService & { latitude: number; longitude: number } {
  return (
    typeof service.latitude === 'number' &&
    Number.isFinite(service.latitude) &&
    typeof service.longitude === 'number' &&
    Number.isFinite(service.longitude)
  );
}

export function VendorMap({ services }: VendorMapProps) {
  const locatedServices = services.filter(isLocated);
  const points = locatedServices.map(
    service => [service.latitude, service.longitude] as [number, number],
  );

  return (
    <section className="min-h-[360px] flex-1 overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-gray-100 bg-gray-50/70 px-5 py-4">
        <div>
          <h3 className="font-bold text-gray-900">Vị trí đề xuất</h3>
          <p className="mt-0.5 text-xs text-gray-500">
            {locatedServices.length > 0
              ? `${locatedServices.length} dịch vụ có vị trí`
              : 'Chưa có dữ liệu vị trí'}
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-medium text-gray-500">
          <MapPin className="h-4 w-4 text-rose-500" />
          Bản đồ
        </div>
      </div>

      <div className="relative h-[calc(100%-73px)] min-h-[290px]">
        <MapContainer
          center={DEFAULT_CENTER}
          zoom={12}
          scrollWheelZoom
          className="h-full w-full"
        >
          <TileLayer
            attribution='&copy; OpenStreetMap contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />

          <FitBounds points={points} />

          {locatedServices.map((service, index) => (
            <CircleMarker
              key={service.id}
              center={[service.latitude, service.longitude]}
              radius={10}
              pathOptions={{
                color: '#e11d48',
                fillColor: '#f43f5e',
                fillOpacity: 0.9,
                weight: 3,
              }}
            >
              <Popup>
                <div className="min-w-[180px]">
                  <p className="font-semibold text-gray-900">
                    {index + 1}. {service.name ?? 'Dịch vụ'}
                  </p>
                  {service.category && (
                    <p className="mt-1 text-xs text-gray-500">{service.category}</p>
                  )}
                  {service.address && (
                    <p className="mt-1 text-xs text-gray-500">{service.address}</p>
                  )}
                  {typeof service.basePrice === 'number' && (
                    <p className="mt-1 text-xs font-bold text-rose-600">
                      {service.basePrice.toLocaleString('vi-VN')} {service.currency ?? 'VND'}
                    </p>
                  )}
                </div>
              </Popup>
            </CircleMarker>
          ))}
        </MapContainer>

        {locatedServices.length === 0 && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-white/65 backdrop-blur-[1px]">
            <div className="mx-6 max-w-sm rounded-2xl border border-gray-200 bg-white/95 px-5 py-4 text-center shadow-sm">
              <MapPin className="mx-auto h-6 w-6 text-rose-500" />
              <p className="mt-2 text-sm font-semibold text-gray-900">
                Chưa thể hiển thị vị trí
              </p>
              <p className="mt-1 text-xs leading-5 text-gray-500">
                Hãy trả về latitude và longitude của từng dịch vụ/vendor từ catalog
                để các đề xuất xuất hiện trên bản đồ.
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
